import { useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Loader2, AlertCircle, PlusCircle, ArrowUpDown, CheckCircle } from "lucide-react";
import { Lead } from "@shared/schema";
import { formatDate } from "@/lib/utils";

export function ActivitySummary() {
  const { data: leads, isLoading, isError } = useQuery<Lead[]>({
    queryKey: ["/api/leads"],
  });

  if (isLoading) {
    return (
      <Card>
        <CardHeader>
          <CardTitle>Resumo de Atividades</CardTitle>
        </CardHeader>
        <CardContent className="h-[350px] flex items-center justify-center">
          <Loader2 className="h-6 w-6 animate-spin text-primary" />
        </CardContent>
      </Card>
    );
  }

  if (isError || !leads) {
    return (
      <Card>
        <CardHeader>
          <CardTitle>Resumo de Atividades</CardTitle>
        </CardHeader>
        <CardContent className="h-[350px] flex items-center justify-center text-red-500">
          <div className="text-center">
            <AlertCircle className="h-8 w-8 mx-auto mb-2" />
            <p>Erro ao carregar dados. Por favor, tente novamente.</p>
          </div>
        </CardContent>
      </Card>
    );
  }

  // Sort leads by updated date (most recent first)
  const sortedLeads = [...leads].sort((a, b) => 
    new Date(b.updatedAt).getTime() - new Date(a.updatedAt).getTime()
  );

  // Take the 10 most recent activities
  const recentActivities = sortedLeads.slice(0, 10);

  // Count leads added in the last 30 days
  const now = new Date();
  const thirtyDaysAgo = new Date(now.setDate(now.getDate() - 30));
  
  const newLeadsCount = leads.filter(lead => 
    new Date(lead.createdAt) > thirtyDaysAgo
  ).length;

  // Count leads moved or sold in the last 30 days
  const movedLeadsCount = leads.filter(lead => 
    new Date(lead.updatedAt) > thirtyDaysAgo && 
    new Date(lead.updatedAt).getTime() !== new Date(lead.createdAt).getTime()
  ).length;

  // Count leads in "Vendidos" status
  const soldLeadsCount = leads.filter(lead => lead.status === "Vendidos").length;

  const getActivityIcon = (lead: Lead) => {
    // If created date is same as updated date, it's a new lead
    if (new Date(lead.createdAt).getTime() === new Date(lead.updatedAt).getTime()) {
      return <PlusCircle className="h-5 w-5 text-green-500" />;
    }
    
    // If status is "Vendidos", it's a sold lead
    if (lead.status === "Vendidos") {
      return <CheckCircle className="h-5 w-5 text-green-500" />;
    }
    
    // Otherwise, it's a moved lead
    return <ArrowUpDown className="h-5 w-5 text-primary" />;
  };

  const getActivityDescription = (lead: Lead) => {
    if (new Date(lead.createdAt).getTime() === new Date(lead.updatedAt).getTime()) {
      return `Novo lead adicionado: ${lead.name}`;
    }
    
    if (lead.status === "Vendidos") {
      return `Lead vendido: ${lead.name}`;
    }
    
    return `Lead atualizado: ${lead.name} (${lead.status})`;
  };

  return (
    <Card>
      <CardHeader>
        <CardTitle>Resumo de Atividades</CardTitle>
      </CardHeader>
      <CardContent>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-6">
          <div className="bg-green-50 p-4 rounded-md border border-green-100">
            <div className="font-medium text-green-700 mb-1">Novos Leads</div>
            <div className="text-2xl font-bold">{newLeadsCount}</div>
            <div className="text-sm text-green-600">Últimos 30 dias</div>
          </div>
          <div className="bg-blue-50 p-4 rounded-md border border-blue-100">
            <div className="font-medium text-blue-700 mb-1">Leads Movidos</div>
            <div className="text-2xl font-bold">{movedLeadsCount}</div>
            <div className="text-sm text-blue-600">Últimos 30 dias</div>
          </div>
          <div className="bg-purple-50 p-4 rounded-md border border-purple-100">
            <div className="font-medium text-purple-700 mb-1">Leads Vendidos</div>
            <div className="text-2xl font-bold">{soldLeadsCount}</div>
            <div className="text-sm text-purple-600">Total acumulado</div>
          </div>
        </div>

        <h3 className="font-medium mb-3">Atividades Recentes</h3>
        {recentActivities.length > 0 ? (
          <div className="space-y-3 max-h-[300px] overflow-y-auto pr-2">
            {recentActivities.map((lead) => (
              <div 
                key={`${lead.id}-${lead.updatedAt}`} 
                className="flex items-start p-3 bg-neutral-50 border border-neutral-100 rounded-md"
              >
                <div className="mr-3 mt-0.5">{getActivityIcon(lead)}</div>
                <div>
                  <div className="font-medium">{getActivityDescription(lead)}</div>
                  <div className="text-xs text-neutral-500">{formatDate(lead.updatedAt)}</div>
                </div>
              </div>
            ))}
          </div>
        ) : (
          <div className="text-center p-4 text-neutral-500">
            Nenhuma atividade recente encontrada
          </div>
        )}
      </CardContent>
    </Card>
  );
}
