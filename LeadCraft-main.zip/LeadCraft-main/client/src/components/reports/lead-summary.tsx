import { useQuery } from "@tanstack/react-query";
import { leadStatusEnum } from "@shared/schema";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, Cell } from "recharts";
import { Loader2, AlertCircle } from "lucide-react";

interface LeadSummaryData {
  total: number;
  byStatus: Record<string, number>;
}

export function LeadSummary() {
  const { data, isLoading, isError } = useQuery<LeadSummaryData>({
    queryKey: ["/api/reports/summary"],
  });

  if (isLoading) {
    return (
      <Card>
        <CardHeader>
          <CardTitle>Distribuição de Leads</CardTitle>
        </CardHeader>
        <CardContent className="h-[350px] flex items-center justify-center">
          <Loader2 className="h-6 w-6 animate-spin text-primary" />
        </CardContent>
      </Card>
    );
  }

  if (isError || !data) {
    return (
      <Card>
        <CardHeader>
          <CardTitle>Distribuição de Leads</CardTitle>
        </CardHeader>
        <CardContent className="h-[350px] flex items-center justify-center text-red-500">
          <div className="text-center">
            <AlertCircle className="h-8 w-8 mx-auto mb-2" />
            <p>Erro ao carregar dados. Por favor, tente novamente.</p>
          </div>
        </CardContent>
      </Card>
    );
  }

  const chartData = leadStatusEnum.options.map(status => ({
    name: status,
    value: data.byStatus[status] || 0
  }));

  // Chart colors
  const colors = [
    "hsl(var(--chart-1))",
    "hsl(var(--chart-2))",
    "hsl(var(--chart-3))",
    "hsl(var(--chart-4))",
    "hsl(var(--chart-5))",
    "hsl(var(--primary))"
  ];

  return (
    <Card>
      <CardHeader>
        <CardTitle>Distribuição de Leads</CardTitle>
      </CardHeader>
      <CardContent>
        <div className="h-[350px]">
          <ResponsiveContainer width="100%" height="100%">
            <BarChart
              data={chartData}
              margin={{
                top: 20,
                right: 30,
                left: 20,
                bottom: 60,
              }}
            >
              <CartesianGrid strokeDasharray="3 3" vertical={false} />
              <XAxis
                dataKey="name"
                angle={-45}
                textAnchor="end"
                height={70}
                tick={{ fontSize: 12 }}
              />
              <YAxis allowDecimals={false} />
              <Tooltip
                formatter={(value) => [`${value} lead${value !== 1 ? 's' : ''}`, 'Quantidade']}
              />
              <Bar dataKey="value" radius={[4, 4, 0, 0]}>
                {chartData.map((entry, index) => (
                  <Cell key={`cell-${index}`} fill={colors[index % colors.length]} />
                ))}
              </Bar>
            </BarChart>
          </ResponsiveContainer>
        </div>
        <div className="mt-4 text-center text-sm text-neutral-600">
          Total de leads: <span className="font-medium">{data.total}</span>
        </div>
      </CardContent>
    </Card>
  );
}
