export function DashboardPreview() {
  return (
    <section className="py-16 bg-neutral-100">
      <div className="container mx-auto px-4">
        <div className="text-center mb-12">
          <h2 className="text-3xl font-bold mb-4">Simplifique seu Fluxo de Trabalho</h2>
          <p className="text-lg text-neutral-700 max-w-2xl mx-auto">
            Veja como é fácil gerenciar seus leads com nossa interface intuitiva de arrastar e soltar.
          </p>
        </div>
        
        <div className="bg-white p-6 rounded-lg shadow-md overflow-hidden">
          {/* Dashboard Preview as SVG for guaranteed compatibility */}
          <div className="overflow-x-auto">
            <div className="min-w-[900px]">
              <svg
                viewBox="0 0 1200 400"
                xmlns="http://www.w3.org/2000/svg"
                className="w-full h-auto"
              >
                {/* Kanban Board Background */}
                <rect width="1200" height="400" fill="#f8fafc" rx="8" />
                
                {/* Column 1: Novos Leads */}
                <g>
                  <rect x="10" y="10" width="190" height="380" fill="#f1f5f9" rx="5" />
                  <text x="25" y="35" fill="#334155" fontWeight="600" fontSize="14">Novos Leads</text>
                  <rect x="140" y="25" width="40" height="20" rx="10" fill="#e2e8f0" />
                  <text x="155" y="39" fill="#64748b" fontSize="12" textAnchor="middle">3</text>
                  
                  {/* Lead Cards */}
                  <rect x="20" y="50" width="170" height="80" fill="white" rx="5" stroke="#e2e8f0" />
                  <text x="30" y="75" fill="#334155" fontWeight="500" fontSize="14">Carlos Silva</text>
                  <text x="30" y="95" fill="#64748b" fontSize="12">carlos.silva@email.com</text>
                  <text x="30" y="115" fill="#94a3b8" fontSize="12">12/05/2023</text>
                  
                  <rect x="20" y="140" width="170" height="80" fill="white" rx="5" stroke="#e2e8f0" />
                  <text x="30" y="165" fill="#334155" fontWeight="500" fontSize="14">Ana Costa</text>
                  <text x="30" y="185" fill="#64748b" fontSize="12">ana.costa@email.com</text>
                  <text x="30" y="205" fill="#94a3b8" fontSize="12">10/05/2023</text>
                  
                  <rect x="20" y="230" width="170" height="80" fill="white" rx="5" stroke="#e2e8f0" />
                  <text x="30" y="255" fill="#334155" fontWeight="500" fontSize="14">Marcelo Santos</text>
                  <text x="30" y="275" fill="#64748b" fontSize="12">marcelo.santos@email.com</text>
                  <text x="30" y="295" fill="#94a3b8" fontSize="12">09/05/2023</text>
                </g>
                
                {/* Column 2: Atendimento Iniciado */}
                <g>
                  <rect x="210" y="10" width="190" height="380" fill="#f1f5f9" rx="5" />
                  <text x="225" y="35" fill="#334155" fontWeight="600" fontSize="14">Atendimento Iniciado</text>
                  <rect x="340" y="25" width="40" height="20" rx="10" fill="#e2e8f0" />
                  <text x="355" y="39" fill="#64748b" fontSize="12" textAnchor="middle">2</text>
                  
                  {/* Lead Cards */}
                  <rect x="220" y="50" width="170" height="80" fill="white" rx="5" stroke="#e2e8f0" />
                  <text x="230" y="75" fill="#334155" fontWeight="500" fontSize="14">Juliana Lima</text>
                  <text x="230" y="95" fill="#64748b" fontSize="12">juliana.lima@email.com</text>
                  <text x="230" y="115" fill="#94a3b8" fontSize="12">08/05/2023</text>
                  
                  <rect x="220" y="140" width="170" height="80" fill="white" rx="5" stroke="#e2e8f0" />
                  <text x="230" y="165" fill="#334155" fontWeight="500" fontSize="14">Roberto Oliveira</text>
                  <text x="230" y="185" fill="#64748b" fontSize="12">roberto.oliveira@email.com</text>
                  <text x="230" y="205" fill="#94a3b8" fontSize="12">07/05/2023</text>
                </g>
                
                {/* Column 3: Agendamento */}
                <g>
                  <rect x="410" y="10" width="190" height="380" fill="#f1f5f9" rx="5" />
                  <text x="425" y="35" fill="#334155" fontWeight="600" fontSize="14">Agendamento</text>
                  <rect x="540" y="25" width="40" height="20" rx="10" fill="#e2e8f0" />
                  <text x="555" y="39" fill="#64748b" fontSize="12" textAnchor="middle">1</text>
                  
                  {/* Lead Cards */}
                  <rect x="420" y="50" width="170" height="80" fill="white" rx="5" stroke="#e2e8f0" />
                  <text x="430" y="75" fill="#334155" fontWeight="500" fontSize="14">Paulo Mendes</text>
                  <text x="430" y="95" fill="#64748b" fontSize="12">paulo.mendes@email.com</text>
                  <text x="430" y="115" fill="#94a3b8" fontSize="12">06/05/2023</text>
                </g>
                
                {/* Column 4: Negociação */}
                <g>
                  <rect x="610" y="10" width="190" height="380" fill="#f1f5f9" rx="5" />
                  <text x="625" y="35" fill="#334155" fontWeight="600" fontSize="14">Negociação</text>
                  <rect x="740" y="25" width="40" height="20" rx="10" fill="#e2e8f0" />
                  <text x="755" y="39" fill="#64748b" fontSize="12" textAnchor="middle">2</text>
                  
                  {/* Lead Cards */}
                  <rect x="620" y="50" width="170" height="80" fill="white" rx="5" stroke="#e2e8f0" />
                  <text x="630" y="75" fill="#334155" fontWeight="500" fontSize="14">Fernanda Souza</text>
                  <text x="630" y="95" fill="#64748b" fontSize="12">fernanda.souza@email.com</text>
                  <text x="630" y="115" fill="#94a3b8" fontSize="12">05/05/2023</text>
                  
                  <rect x="620" y="140" width="170" height="80" fill="white" rx="5" stroke="#e2e8f0" />
                  <text x="630" y="165" fill="#334155" fontWeight="500" fontSize="14">Ricardo Almeida</text>
                  <text x="630" y="185" fill="#64748b" fontSize="12">ricardo.almeida@email.com</text>
                  <text x="630" y="205" fill="#94a3b8" fontSize="12">03/05/2023</text>
                </g>
                
                {/* Column 5: Follow-up */}
                <g>
                  <rect x="810" y="10" width="190" height="380" fill="#f1f5f9" rx="5" />
                  <text x="825" y="35" fill="#334155" fontWeight="600" fontSize="14">Follow-up</text>
                  <rect x="940" y="25" width="40" height="20" rx="10" fill="#e2e8f0" />
                  <text x="955" y="39" fill="#64748b" fontSize="12" textAnchor="middle">1</text>
                  
                  {/* Lead Cards */}
                  <rect x="820" y="50" width="170" height="80" fill="white" rx="5" stroke="#e2e8f0" />
                  <text x="830" y="75" fill="#334155" fontWeight="500" fontSize="14">Camila Ferreira</text>
                  <text x="830" y="95" fill="#64748b" fontSize="12">camila.ferreira@email.com</text>
                  <text x="830" y="115" fill="#94a3b8" fontSize="12">02/05/2023</text>
                </g>
                
                {/* Column 6: Vendidos */}
                <g>
                  <rect x="1010" y="10" width="180" height="380" fill="#f1f5f9" rx="5" />
                  <text x="1025" y="35" fill="#334155" fontWeight="600" fontSize="14">Vendidos</text>
                  <rect x="1130" y="25" width="40" height="20" rx="10" fill="#e2e8f0" />
                  <text x="1145" y="39" fill="#64748b" fontSize="12" textAnchor="middle">1</text>
                  
                  {/* Lead Cards */}
                  <rect x="1020" y="50" width="160" height="80" fill="white" rx="5" stroke="#e2e8f0" />
                  <text x="1030" y="75" fill="#334155" fontWeight="500" fontSize="14">Lucia Martins</text>
                  <text x="1030" y="95" fill="#64748b" fontSize="12">lucia.martins@email.com</text>
                  <text x="1030" y="115" fill="#94a3b8" fontSize="12">01/05/2023</text>
                </g>
              </svg>
            </div>
          </div>
        </div>
        
        <div className="mt-8 text-center">
          <a href="/auth" className="inline-block bg-primary text-white font-medium px-6 py-3 rounded-md hover:bg-primary/90 transition shadow-sm">
            Experimente Agora
          </a>
        </div>
      </div>
    </section>
  );
}
