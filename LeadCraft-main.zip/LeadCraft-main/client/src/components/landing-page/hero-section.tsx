import { Link } from "wouter";
import { Button } from "@/components/ui/button";

export function HeroSection() {
  return (
    <section className="pt-10 pb-16 md:pt-16 md:pb-24">
      <div className="container mx-auto px-4">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
          <div>
            <h1 className="text-3xl md:text-4xl lg:text-5xl font-bold leading-tight mb-4">
              Simplifique seu Gerenciamento de Leads com o LeadUP
            </h1>
            <p className="text-lg text-neutral-700 mb-8">
              O CRM fácil de usar, criado para empresas em crescimento. Acompanhe, gerencie e feche leads sem esforço.
            </p>
            <div className="mb-4">
              <Link href="/auth">
                <Button size="lg" className="text-lg px-6 py-3 h-auto shadow-md">
                  Comece seu Plano Gratuito Agora!
                </Button>
              </Link>
            </div>
            <p className="text-neutral-700 text-sm">
              Sem necessidade de cartão de crédito. Faça upgrade a qualquer momento.
            </p>
          </div>
          <div className="hidden lg:block bg-neutral-100 rounded-xl p-6 shadow-md">
            <svg
              className="w-full h-auto"
              viewBox="0 0 800 500"
              xmlns="http://www.w3.org/2000/svg"
            >
              <rect width="800" height="500" fill="#f8fafc" rx="10" />
              <rect x="30" y="30" width="740" height="60" fill="#e2e8f0" rx="5" />
              <rect x="50" y="45" width="200" height="30" fill="#4A90E2" rx="3" />
              <rect x="280" y="45" width="120" height="30" fill="#94a3b8" rx="3" />
              <rect x="430" y="45" width="120" height="30" fill="#94a3b8" rx="3" />
              <rect x="580" y="45" width="170" height="30" fill="#94a3b8" rx="3" />
              
              <rect x="30" y="110" width="180" height="360" fill="#e2e8f0" rx="5" />
              <rect x="45" y="125" width="150" height="40" fill="#4A90E2" rx="3" />
              <rect x="45" y="175" width="150" height="80" fill="white" rx="3" />
              <rect x="45" y="265" width="150" height="80" fill="white" rx="3" />
              <rect x="45" y="355" width="150" height="80" fill="white" rx="3" />
              
              <rect x="230" y="110" width="180" height="360" fill="#e2e8f0" rx="5" />
              <rect x="245" y="125" width="150" height="40" fill="#60a5fa" rx="3" />
              <rect x="245" y="175" width="150" height="80" fill="white" rx="3" />
              <rect x="245" y="265" width="150" height="80" fill="white" rx="3" />
              
              <rect x="430" y="110" width="180" height="360" fill="#e2e8f0" rx="5" />
              <rect x="445" y="125" width="150" height="40" fill="#f59e0b" rx="3" />
              <rect x="445" y="175" width="150" height="80" fill="white" rx="3" />
              <rect x="445" y="265" width="150" height="80" fill="white" rx="3" />
              
              <rect x="630" y="110" width="180" height="360" fill="#e2e8f0" rx="5" />
              <rect x="645" y="125" width="150" height="40" fill="#10b981" rx="3" />
              <rect x="645" y="175" width="150" height="80" fill="white" rx="3" />
            </svg>
          </div>
        </div>
      </div>
    </section>
  );
}
