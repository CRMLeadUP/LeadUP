import { Link } from "wouter";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Check } from "lucide-react";

export function Pricing() {
  return (
    <section id="pricing" className="py-16 bg-neutral-100">
      <div className="container mx-auto px-4">
        <div className="text-center mb-12">
          <h2 className="text-3xl font-bold mb-4">Escolha Seu Plano</h2>
          <p className="text-lg text-neutral-700 max-w-2xl mx-auto">
            Planos flexíveis para empresas de todos os tamanhos.
          </p>
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8 max-w-6xl mx-auto">
          {/* Free Plan */}
          <Card className="border-neutral-200 shadow-md flex flex-col h-full">
            <CardContent className="pt-8 pb-8">
              <h3 className="text-2xl font-bold mb-2">Plano Gratuito</h3>
              <div className="text-3xl font-bold mb-4">
                R$ 0<span className="text-lg font-normal text-neutral-700">/mês</span>
              </div>
              <p className="text-neutral-700 mb-6">
                Perfeito para começar e experimentar as funcionalidades essenciais.
              </p>
              <ul className="mb-8 flex-grow space-y-3">
                <li className="flex items-start">
                  <Check className="h-5 w-5 text-green-500 mt-0.5 mr-2 flex-shrink-0" />
                  <span>Crie até 10 leads</span>
                </li>
                <li className="flex items-start">
                  <Check className="h-5 w-5 text-green-500 mt-0.5 mr-2 flex-shrink-0" />
                  <span>Gerencie leads em todas as etapas</span>
                </li>
                <li className="flex items-start">
                  <Check className="h-5 w-5 text-green-500 mt-0.5 mr-2 flex-shrink-0" />
                  <span>Estatísticas básicas</span>
                </li>
                <li className="flex items-start">
                  <Check className="h-5 w-5 text-green-500 mt-0.5 mr-2 flex-shrink-0" />
                  <span>Atendimento por email</span>
                </li>
              </ul>
              <Link href="/auth">
                <Button variant="outline" className="w-full">
                  Começar Grátis
                </Button>
              </Link>
            </CardContent>
          </Card>
          
          {/* PRO Plan */}
          <Card className="border-2 border-primary shadow-md flex flex-col h-full relative overflow-hidden">
            <div className="absolute top-0 right-0 bg-primary text-white text-xs py-1 px-3 transform rotate-45 translate-x-[2.1rem] translate-y-[1.1rem]">
              POPULAR
            </div>
            
            <CardContent className="pt-8 pb-8">
              <h3 className="text-2xl font-bold mb-2">Plano PRO</h3>
              <div className="text-3xl font-bold mb-4">
                R$ 19,90<span className="text-lg font-normal text-neutral-700">/mês</span>
              </div>
              <p className="text-neutral-700 mb-6">
                Ideal para empresas em crescimento que precisam de mais recursos.
              </p>
              <ul className="mb-8 flex-grow space-y-3">
                <li className="flex items-start">
                  <Check className="h-5 w-5 text-green-500 mt-0.5 mr-2 flex-shrink-0" />
                  <span>Crie até 300 leads</span>
                </li>
                <li className="flex items-start">
                  <Check className="h-5 w-5 text-green-500 mt-0.5 mr-2 flex-shrink-0" />
                  <span>Todas as funcionalidades do plano gratuito</span>
                </li>
                <li className="flex items-start">
                  <Check className="h-5 w-5 text-green-500 mt-0.5 mr-2 flex-shrink-0" />
                  <span>Estatísticas avançadas</span>
                </li>
                <li className="flex items-start">
                  <Check className="h-5 w-5 text-green-500 mt-0.5 mr-2 flex-shrink-0" />
                  <span>Suporte prioritário</span>
                </li>
                <li className="flex items-start">
                  <Check className="h-5 w-5 text-green-500 mt-0.5 mr-2 flex-shrink-0" />
                  <span>Integração com WhatsApp</span>
                </li>
                <li className="flex items-start">
                  <Check className="h-5 w-5 text-green-500 mt-0.5 mr-2 flex-shrink-0" />
                  <span>Exportação de relatórios</span>
                </li>
              </ul>
              <Link href="/auth">
                <Button className="w-full">
                  Assinar Plano PRO
                </Button>
              </Link>
            </CardContent>
          </Card>
          
          {/* Advanced Plan */}
          <Card className="border-2 border-purple-500 shadow-md flex flex-col h-full relative overflow-hidden">
            <div className="absolute top-0 right-0 bg-purple-500 text-white text-xs py-1 px-3 transform rotate-45 translate-x-[2.1rem] translate-y-[1.1rem]">
              PREMIUM
            </div>
            
            <CardContent className="pt-8 pb-8">
              <h3 className="text-2xl font-bold mb-2">Plano Advanced</h3>
              <div className="text-3xl font-bold mb-4">
                R$ 49,90<span className="text-lg font-normal text-neutral-700">/mês</span>
              </div>
              <p className="text-neutral-700 mb-6">
                Solução completa para empresas com grandes demandas e necessidades avançadas.
              </p>
              <ul className="mb-8 flex-grow space-y-3">
                <li className="flex items-start">
                  <Check className="h-5 w-5 text-green-500 mt-0.5 mr-2 flex-shrink-0" />
                  <span>Crie até 999 leads</span>
                </li>
                <li className="flex items-start">
                  <Check className="h-5 w-5 text-green-500 mt-0.5 mr-2 flex-shrink-0" />
                  <span>Todas as funcionalidades do plano PRO</span>
                </li>
                <li className="flex items-start">
                  <Check className="h-5 w-5 text-green-500 mt-0.5 mr-2 flex-shrink-0" />
                  <span>Estatísticas premium</span>
                </li>
                <li className="flex items-start">
                  <Check className="h-5 w-5 text-green-500 mt-0.5 mr-2 flex-shrink-0" />
                  <span>Suporte premium 24/7</span>
                </li>
                <li className="flex items-start">
                  <Check className="h-5 w-5 text-green-500 mt-0.5 mr-2 flex-shrink-0" />
                  <span>API para integrações</span>
                </li>
                <li className="flex items-start">
                  <Check className="h-5 w-5 text-green-500 mt-0.5 mr-2 flex-shrink-0" />
                  <span>Exportação avançada de dados</span>
                </li>
              </ul>
              <Link href="/auth">
                <Button className="w-full" style={{ backgroundColor: "#9333ea", borderColor: "#9333ea" }}>
                  Assinar Plano Advanced
                </Button>
              </Link>
            </CardContent>
          </Card>
        </div>
      </div>
    </section>
  );
}
