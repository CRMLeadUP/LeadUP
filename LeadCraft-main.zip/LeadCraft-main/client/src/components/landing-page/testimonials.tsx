import { Card, CardContent } from "@/components/ui/card";
import { Star } from "lucide-react";

export function Testimonials() {
  return (
    <section id="testimonials" className="py-16">
      <div className="container mx-auto px-4">
        <div className="text-center mb-12">
          <h2 className="text-3xl font-bold mb-4">O Que Nossos Usuários Estão Dizendo</h2>
          <p className="text-lg text-neutral-700 max-w-2xl mx-auto">
            Junte-se a milhares de usuários satisfeitos gerenciando suas vendas sem esforço.
          </p>
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          {/* Testimonial 1 */}
          <Card className="shadow-sm border border-neutral-200">
            <CardContent className="pt-6">
              <div className="flex items-center mb-4">
                <div className="w-12 h-12 bg-neutral-200 rounded-full flex items-center justify-center text-neutral-600 mr-4">
                  <span className="text-lg font-bold">JS</span>
                </div>
                <div>
                  <h4 className="font-semibold">João Silva</h4>
                  <p className="text-sm text-neutral-700">Gerente de Vendas</p>
                </div>
              </div>
              <p className="text-neutral-700 italic">
                "O LeadUP simplificou nosso gerenciamento de leads. A funcionalidade de arrastar e soltar é uma revolução!"
              </p>
              <div className="mt-4 flex text-yellow-400">
                <Star className="fill-current h-5 w-5" />
                <Star className="fill-current h-5 w-5" />
                <Star className="fill-current h-5 w-5" />
                <Star className="fill-current h-5 w-5" />
                <Star className="fill-current h-5 w-5" />
              </div>
            </CardContent>
          </Card>
          
          {/* Testimonial 2 */}
          <Card className="shadow-sm border border-neutral-200">
            <CardContent className="pt-6">
              <div className="flex items-center mb-4">
                <div className="w-12 h-12 bg-neutral-200 rounded-full flex items-center justify-center text-neutral-600 mr-4">
                  <span className="text-lg font-bold">MO</span>
                </div>
                <div>
                  <h4 className="font-semibold">Mariana Oliveira</h4>
                  <p className="text-sm text-neutral-700">Empresária</p>
                </div>
              </div>
              <p className="text-neutral-700 italic">
                "Acessível e eficaz. O plano gratuito foi perfeito para começar e o PRO tem um custo-benefício excelente."
              </p>
              <div className="mt-4 flex text-yellow-400">
                <Star className="fill-current h-5 w-5" />
                <Star className="fill-current h-5 w-5" />
                <Star className="fill-current h-5 w-5" />
                <Star className="fill-current h-5 w-5" />
                <Star className="fill-current h-5 w-5" />
              </div>
            </CardContent>
          </Card>
          
          {/* Testimonial 3 */}
          <Card className="shadow-sm border border-neutral-200">
            <CardContent className="pt-6">
              <div className="flex items-center mb-4">
                <div className="w-12 h-12 bg-neutral-200 rounded-full flex items-center justify-center text-neutral-600 mr-4">
                  <span className="text-lg font-bold">AS</span>
                </div>
                <div>
                  <h4 className="font-semibold">André Santos</h4>
                  <p className="text-sm text-neutral-700">Pequeno Empresário</p>
                </div>
              </div>
              <p className="text-neutral-700 italic">
                "Como dono de uma pequena empresa, o LeadUP é exatamente o que precisávamos para organizar nossos contatos."
              </p>
              <div className="mt-4 flex text-yellow-400">
                <Star className="fill-current h-5 w-5" />
                <Star className="fill-current h-5 w-5" />
                <Star className="fill-current h-5 w-5" />
                <Star className="fill-current h-5 w-5" />
                <Star className="fill-current h-5 w-5 opacity-50" />
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </section>
  );
}
