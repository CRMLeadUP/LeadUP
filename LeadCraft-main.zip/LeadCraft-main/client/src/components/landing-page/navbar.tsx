import { useState } from "react";
import { Link } from "wouter";
import { Button } from "@/components/ui/button";
import { Menu, X, ChartLine } from "lucide-react";

export function Navbar() {
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  const toggleMobileMenu = () => setMobileMenuOpen(!mobileMenuOpen);

  return (
    <header className="sticky top-0 bg-white shadow-sm z-50">
      <nav className="container mx-auto px-4 py-3 flex justify-between items-center">
        <div className="flex items-center">
          <Link href="/" className="text-2xl font-bold text-primary flex items-center">
            <ChartLine className="mr-2" />
            <span>LeadUP</span>
          </Link>
        </div>
        
        {/* Desktop Menu */}
        <div className="hidden md:flex items-center space-x-6">
          <a href="#features" className="text-neutral-700 hover:text-primary transition">
            Funcionalidades
          </a>
          <a href="#pricing" className="text-neutral-700 hover:text-primary transition">
            Preços
          </a>
          <a href="#testimonials" className="text-neutral-700 hover:text-primary transition">
            Depoimentos
          </a>
          <a href="#" className="text-neutral-700 hover:text-primary transition">
            Contato
          </a>
          <Link href="/auth" className="text-primary font-medium hover:text-primary/80 transition">
            Entrar
          </Link>
          <Link href="/auth">
            <Button>Começar Grátis</Button>
          </Link>
        </div>
        
        {/* Mobile Menu Toggle */}
        <button 
          className="md:hidden text-neutral-900" 
          onClick={toggleMobileMenu}
          aria-label={mobileMenuOpen ? "Fechar menu" : "Abrir menu"}
        >
          {mobileMenuOpen ? <X className="h-6 w-6" /> : <Menu className="h-6 w-6" />}
        </button>
      </nav>
      
      {/* Mobile Menu */}
      {mobileMenuOpen && (
        <div className="md:hidden bg-white">
          <div className="container mx-auto px-4 py-3 flex flex-col space-y-3">
            <a 
              href="#features" 
              className="text-neutral-700 py-2 border-b border-neutral-200"
              onClick={() => setMobileMenuOpen(false)}
            >
              Funcionalidades
            </a>
            <a 
              href="#pricing" 
              className="text-neutral-700 py-2 border-b border-neutral-200"
              onClick={() => setMobileMenuOpen(false)}
            >
              Preços
            </a>
            <a 
              href="#testimonials" 
              className="text-neutral-700 py-2 border-b border-neutral-200"
              onClick={() => setMobileMenuOpen(false)}
            >
              Depoimentos
            </a>
            <a 
              href="#" 
              className="text-neutral-700 py-2 border-b border-neutral-200"
              onClick={() => setMobileMenuOpen(false)}
            >
              Contato
            </a>
            <Link 
              href="/auth" 
              className="text-primary font-medium py-2"
              onClick={() => setMobileMenuOpen(false)}
            >
              Entrar
            </Link>
            <Link 
              href="/auth" 
              className="bg-primary text-white px-4 py-2 rounded-md text-center mt-2"
              onClick={() => setMobileMenuOpen(false)}
            >
              Começar Grátis
            </Link>
          </div>
        </div>
      )}
    </header>
  );
}
