import { Link } from "wouter";
import { Button } from "@/components/ui/button";
import { MessageSquare } from "lucide-react";

export function CTASection() {
  return (
    <section className="py-16">
      <div className="container mx-auto px-4">
        <div className="bg-primary/10 p-8 md:p-12 rounded-xl text-center">
          <h2 className="text-3xl font-bold mb-4">Pronto para Simplificar seu Gerenciamento de Leads?</h2>
          <p className="text-lg text-neutral-700 max-w-2xl mx-auto mb-8">
            Comece gratuitamente e experimente o poder do LeadUP.
          </p>
          <div className="flex flex-col sm:flex-row justify-center gap-4">
            <Link href="/auth">
              <Button size="lg" className="shadow-sm">
                Começar Agora
              </Button>
            </Link>
            <a href="#" className="inline-flex items-center justify-center bg-white text-primary border border-primary px-6 py-3 rounded-md font-medium hover:bg-primary/10 transition">
              <MessageSquare className="mr-2 h-5 w-5" />
              Fale Conosco
            </a>
          </div>
          <p className="text-sm text-neutral-700 mt-4">
            Sem necessidade de cartão de crédito. Cancele a qualquer momento.
          </p>
        </div>
      </div>
    </section>
  );
}
