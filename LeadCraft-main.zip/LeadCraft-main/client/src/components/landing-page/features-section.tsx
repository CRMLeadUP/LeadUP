import { 
  BarChart, 
  Users, 
  Tag, 
  Rocket, 
  MessageSquare,
  ArrowUp10
} from "lucide-react";

export function FeaturesSection() {
  return (
    <section id="features" className="py-16 bg-neutral-100">
      <div className="container mx-auto px-4">
        <div className="text-center mb-12">
          <h2 className="text-3xl font-bold mb-4">Por que escolher o LeadUP?</h2>
          <p className="text-lg text-neutral-700 max-w-2xl mx-auto">
            Tudo o que você precisa para otimizar seu processo de vendas em um só lugar.
          </p>
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {/* Feature 1 */}
          <div className="bg-white p-6 rounded-lg shadow-sm">
            <div className="text-primary text-3xl mb-4">
              <ArrowUp10 className="h-10 w-10" />
            </div>
            <h3 className="text-xl font-semibold mb-3">Gestão Simples de Leads</h3>
            <p className="text-neutral-700">
              Arraste e solte leads entre etapas como "Novos Leads", "Negociação" e "Vendidos".
            </p>
          </div>
          
          {/* Feature 2 */}
          <div className="bg-white p-6 rounded-lg shadow-sm">
            <div className="text-primary text-3xl mb-4">
              <BarChart className="h-10 w-10" />
            </div>
            <h3 className="text-xl font-semibold mb-3">Análises em Tempo Real</h3>
            <p className="text-neutral-700">
              Acompanhe o desempenho e o progresso com gráficos dinâmicos e relatórios detalhados.
            </p>
          </div>
          
          {/* Feature 3 */}
          <div className="bg-white p-6 rounded-lg shadow-sm">
            <div className="text-primary text-3xl mb-4">
              <Users className="h-10 w-10" />
            </div>
            <h3 className="text-xl font-semibold mb-3">Design Intuitivo</h3>
            <p className="text-neutral-700">
              Sem necessidade de treinamento - comece a usar imediatamente com nossa interface amigável.
            </p>
          </div>
          
          {/* Feature 4 */}
          <div className="bg-white p-6 rounded-lg shadow-sm">
            <div className="text-primary text-3xl mb-4">
              <Tag className="h-10 w-10" />
            </div>
            <h3 className="text-xl font-semibold mb-3">Plano Gratuito</h3>
            <p className="text-neutral-700">
              Comece sem custos com até 10 leads para experimentar todas as funcionalidades essenciais.
            </p>
          </div>
          
          {/* Feature 5 */}
          <div className="bg-white p-6 rounded-lg shadow-sm">
            <div className="text-primary text-3xl mb-4">
              <Rocket className="h-10 w-10" />
            </div>
            <h3 className="text-xl font-semibold mb-3">Plano PRO Acessível</h3>
            <p className="text-neutral-700">
              Amplie para até 300 leads por apenas R$ 19,90/mês com recursos avançados.
            </p>
          </div>
          
          {/* Feature 6 */}
          <div className="bg-white p-6 rounded-lg shadow-sm">
            <div className="text-primary text-3xl mb-4">
              <MessageSquare className="h-10 w-10" />
            </div>
            <h3 className="text-xl font-semibold mb-3">Integração com WhatsApp</h3>
            <p className="text-neutral-700">
              Conecte-se diretamente com seus leads pelo WhatsApp sem sair da plataforma.
            </p>
          </div>
        </div>
      </div>
    </section>
  );
}
