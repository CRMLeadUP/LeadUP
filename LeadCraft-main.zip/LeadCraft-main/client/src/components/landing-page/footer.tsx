import { Link } from "wouter";
import { ChartLine, MessageSquare, Facebook, Instagram, Linkedin, Twitter } from "lucide-react";

export function Footer() {
  return (
    <footer className="bg-neutral-900 text-white py-12">
      <div className="container mx-auto px-4">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
          {/* Column 1: Product */}
          <div>
            <h3 className="text-lg font-semibold mb-4">Produto</h3>
            <ul className="space-y-2">
              <li><a href="#features" className="text-neutral-300 hover:text-white transition">Funcionalidades</a></li>
              <li><a href="#pricing" className="text-neutral-300 hover:text-white transition">Preços</a></li>
              <li><a href="#" className="text-neutral-300 hover:text-white transition">Blog</a></li>
            </ul>
          </div>
          
          {/* Column 2: Company */}
          <div>
            <h3 className="text-lg font-semibold mb-4">Empresa</h3>
            <ul className="space-y-2">
              <li><a href="#" className="text-neutral-300 hover:text-white transition">Sobre Nós</a></li>
              <li><a href="#" className="text-neutral-300 hover:text-white transition">Carreiras</a></li>
              <li><a href="#" className="text-neutral-300 hover:text-white transition">Contato</a></li>
            </ul>
          </div>
          
          {/* Column 3: Support */}
          <div>
            <h3 className="text-lg font-semibold mb-4">Suporte</h3>
            <ul className="space-y-2">
              <li><a href="#" className="text-neutral-300 hover:text-white transition">Central de Ajuda</a></li>
              <li><a href="#" className="text-neutral-300 hover:text-white transition">FAQs</a></li>
              <li><a href="#" className="text-neutral-300 hover:text-white transition">Política de Privacidade</a></li>
            </ul>
          </div>
          
          {/* Column 4: Social Media */}
          <div>
            <h3 className="text-lg font-semibold mb-4">Siga-nos</h3>
            <div className="flex space-x-4">
              <a href="#" className="text-neutral-300 hover:text-white transition">
                <Facebook className="h-6 w-6" />
              </a>
              <a href="#" className="text-neutral-300 hover:text-white transition">
                <Instagram className="h-6 w-6" />
              </a>
              <a href="#" className="text-neutral-300 hover:text-white transition">
                <Linkedin className="h-6 w-6" />
              </a>
              <a href="#" className="text-neutral-300 hover:text-white transition">
                <Twitter className="h-6 w-6" />
              </a>
            </div>
            <div className="mt-6">
              <a href="#" className="flex items-center bg-primary/20 text-white px-4 py-3 rounded-md hover:bg-primary/30 transition">
                <MessageSquare className="h-5 w-5 mr-2" />
                <span>Fale Conosco</span>
              </a>
            </div>
          </div>
        </div>
        
        <div className="border-t border-neutral-700 mt-8 pt-8 text-center text-sm text-neutral-300">
          <div className="flex items-center justify-center mb-4">
            <ChartLine className="h-5 w-5 mr-2" />
            <span className="font-bold">LeadUP</span>
          </div>
          © {new Date().getFullYear()} LeadUP. Todos os direitos reservados.
        </div>
      </div>
    </footer>
  );
}
