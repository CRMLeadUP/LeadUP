import { UserPlus, ListChecks, Handshake } from "lucide-react";

export function HowItWorks() {
  return (
    <section className="py-16">
      <div className="container mx-auto px-4">
        <div className="text-center mb-12">
          <h2 className="text-3xl font-bold mb-4">Como o LeadUP Funciona</h2>
          <p className="text-lg text-neutral-700 max-w-2xl mx-auto">
            Um processo simples de 3 etapas para revolucionar seu gerenciamento de leads.
          </p>
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          {/* Step 1 */}
          <div className="text-center">
            <div className="bg-primary/10 text-primary w-16 h-16 rounded-full flex items-center justify-center text-2xl mx-auto mb-4">
              <UserPlus className="h-8 w-8" />
            </div>
            <h3 className="text-xl font-semibold mb-3">Cadastre-se</h3>
            <p className="text-neutral-700">
              Crie sua conta em menos de um minuto e acesse imediatamente.
            </p>
          </div>
          
          {/* Step 2 */}
          <div className="text-center">
            <div className="bg-primary/10 text-primary w-16 h-16 rounded-full flex items-center justify-center text-2xl mx-auto mb-4">
              <ListChecks className="h-8 w-8" />
            </div>
            <h3 className="text-xl font-semibold mb-3">Gerencie Leads</h3>
            <p className="text-neutral-700">
              Organize e acompanhe seus leads em diferentes estágios do funil.
            </p>
          </div>
          
          {/* Step 3 */}
          <div className="text-center">
            <div className="bg-primary/10 text-primary w-16 h-16 rounded-full flex items-center justify-center text-2xl mx-auto mb-4">
              <Handshake className="h-8 w-8" />
            </div>
            <h3 className="text-xl font-semibold mb-3">Feche Negócios</h3>
            <p className="text-neutral-700">
              Monitore o progresso, faça follow-ups e faça sua empresa crescer.
            </p>
          </div>
        </div>
      </div>
    </section>
  );
}
