import { useState } from "react";
import { useMutation, useQuery } from "@tanstack/react-query";
import { Card, CardContent } from "@/components/ui/card";
import { Lead } from "@shared/schema";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { Mail, Phone, Calendar, DollarSign, Clock, CheckCircle, MoreVertical, Edit, Trash2, X, MessageSquare } from "lucide-react";
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger } from "@/components/ui/dropdown-menu";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter, DialogClose } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { formatDate } from "@/lib/utils";
import { useToast } from "@/hooks/use-toast";
import { useAuth } from "@/hooks/use-auth";

interface LeadCardProps {
  lead: Lead;
  onDragStart: (e: React.DragEvent, lead: Lead) => void;
}

export function LeadCard({ lead, onDragStart }: LeadCardProps) {
  const { toast } = useToast();
  const { user } = useAuth();
  const [isEditDialogOpen, setIsEditDialogOpen] = useState(false);
  const [isDeleteDialogOpen, setIsDeleteDialogOpen] = useState(false);
  const [leadData, setLeadData] = useState({
    name: lead.name,
    email: lead.email || "",
    phone: lead.phone || "",
    notes: lead.notes || ""
  });
  
  const isPro = user?.plan === "pro";

  const statusIcons = {
    "Novos Leads": <Mail className="h-4 w-4 text-primary" />,
    "Atendimento Iniciado": <Phone className="h-4 w-4 text-green-500" />,
    "Agendamento": <Calendar className="h-4 w-4 text-orange-500" />,
    "Negociação": <DollarSign className="h-4 w-4 text-yellow-500" />,
    "Follow-up": <Clock className="h-4 w-4 text-purple-500" />,
    "Vendidos": <CheckCircle className="h-4 w-4 text-green-500" />
  };

  const updateLeadMutation = useMutation({
    mutationFn: async (data: Partial<Lead>) => {
      const res = await apiRequest("PUT", `/api/leads/${lead.id}`, data);
      return await res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/leads"] });
      toast({
        title: "Lead atualizado",
        description: "As informações do lead foram atualizadas com sucesso.",
      });
      setIsEditDialogOpen(false);
    },
    onError: (error: Error) => {
      toast({
        title: "Erro ao atualizar lead",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  const deleteLeadMutation = useMutation({
    mutationFn: async () => {
      await apiRequest("DELETE", `/api/leads/${lead.id}`);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/leads"] });
      toast({
        title: "Lead excluído",
        description: "O lead foi excluído com sucesso.",
      });
      setIsDeleteDialogOpen(false);
    },
    onError: (error: Error) => {
      toast({
        title: "Erro ao excluir lead",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    const { name, value } = e.target;
    setLeadData(prev => ({ ...prev, [name]: value }));
  };

  const handleUpdate = () => {
    updateLeadMutation.mutate({
      name: leadData.name,
      email: leadData.email || null,
      phone: leadData.phone || null,
      notes: leadData.notes || null
    });
  };
  
  const formatWhatsAppNumber = (phone: string): string => {
    // Remove non-digit characters
    const digits = phone.replace(/\D/g, '');
    
    // If it doesn't start with country code, add Brazil's code (55)
    if (!digits.startsWith('55') && digits.length <= 11) {
      return `55${digits}`;
    }
    
    return digits;
  };
  
  const handleWhatsAppClick = () => {
    if (!lead.phone) {
      toast({
        title: "Telefone não disponível",
        description: "Este lead não possui número de telefone cadastrado.",
        variant: "destructive",
      });
      return;
    }
    
    const formattedNumber = formatWhatsAppNumber(lead.phone);
    const whatsappUrl = `https://wa.me/${formattedNumber}`;
    window.open(whatsappUrl, '_blank');
  };

  return (
    <>
      <Card 
        className="bg-white mb-3 cursor-pointer hover:shadow-md transition"
        draggable
        onDragStart={(e) => onDragStart(e, lead)}
      >
        <CardContent className="p-3">
          <div className="flex justify-between items-start">
            <h4 className="font-medium">{lead.name}</h4>
            <DropdownMenu>
              <DropdownMenuTrigger asChild>
                <Button variant="ghost" size="sm" className="h-6 w-6 p-0">
                  <MoreVertical className="h-4 w-4" />
                </Button>
              </DropdownMenuTrigger>
              <DropdownMenuContent align="end">
                <DropdownMenuItem onClick={() => setIsEditDialogOpen(true)}>
                  <Edit className="mr-2 h-4 w-4" />
                  <span>Editar</span>
                </DropdownMenuItem>
                <DropdownMenuItem onClick={() => setIsDeleteDialogOpen(true)} className="text-red-600">
                  <Trash2 className="mr-2 h-4 w-4" />
                  <span>Excluir</span>
                </DropdownMenuItem>
              </DropdownMenuContent>
            </DropdownMenu>
          </div>
          
          {lead.email && (
            <p className="text-xs text-neutral-700 mt-1">{lead.email}</p>
          )}
          
          {lead.phone && (
            <div className="flex items-center justify-between mt-1">
              <p className="text-xs text-neutral-700">{lead.phone}</p>
              {isPro && lead.phone && (
                <Button 
                  variant="ghost" 
                  size="sm" 
                  className="h-6 px-2 py-0 bg-green-50 hover:bg-green-100 text-green-600" 
                  onClick={(e) => {
                    e.stopPropagation();
                    handleWhatsAppClick();
                  }}
                >
                  <MessageSquare className="h-3 w-3 mr-1" />
                  <span className="text-xs">WhatsApp</span>
                </Button>
              )}
            </div>
          )}
          
          <div className="flex justify-between items-center mt-2">
            <span className="text-xs text-neutral-700">{formatDate(lead.createdAt)}</span>
            <div className="flex items-center">
              {statusIcons[lead.status as keyof typeof statusIcons] || <Mail className="h-4 w-4 text-primary" />}
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Edit Dialog */}
      <Dialog open={isEditDialogOpen} onOpenChange={setIsEditDialogOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Editar Lead</DialogTitle>
          </DialogHeader>
          <div className="space-y-4 py-2">
            <div className="space-y-2">
              <Label htmlFor="name">Nome</Label>
              <Input
                id="name"
                name="name"
                value={leadData.name}
                onChange={handleInputChange}
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="email">Email</Label>
              <Input
                id="email"
                name="email"
                type="email"
                value={leadData.email}
                onChange={handleInputChange}
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="phone">Telefone</Label>
              <Input
                id="phone"
                name="phone"
                value={leadData.phone}
                onChange={handleInputChange}
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="notes">Notas</Label>
              <Textarea
                id="notes"
                name="notes"
                value={leadData.notes}
                onChange={handleInputChange}
                rows={3}
              />
            </div>
          </div>
          <DialogFooter>
            <DialogClose asChild>
              <Button variant="outline" type="button">
                Cancelar
              </Button>
            </DialogClose>
            <Button 
              type="button" 
              onClick={handleUpdate}
              disabled={updateLeadMutation.isPending}
            >
              {updateLeadMutation.isPending ? "Salvando..." : "Salvar alterações"}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Delete Confirmation Dialog */}
      <Dialog open={isDeleteDialogOpen} onOpenChange={setIsDeleteDialogOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle className="flex items-center">
              <X className="h-5 w-5 text-destructive mr-2" />
              Excluir Lead
            </DialogTitle>
          </DialogHeader>
          <p>
            Tem certeza que deseja excluir o lead <strong>{lead.name}</strong>? Essa ação não pode ser desfeita.
          </p>
          <DialogFooter>
            <DialogClose asChild>
              <Button variant="outline" type="button">
                Cancelar
              </Button>
            </DialogClose>
            <Button 
              variant="destructive" 
              type="button" 
              onClick={() => deleteLeadMutation.mutate()}
              disabled={deleteLeadMutation.isPending}
            >
              {deleteLeadMutation.isPending ? "Excluindo..." : "Sim, excluir"}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </>
  );
}
