import { useState } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { Lead, LeadStatus, leadStatusEnum } from "@shared/schema";
import { Column } from "./column";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { AlertCircle, Loader2 } from "lucide-react";

export function Board() {
  const { toast } = useToast();
  const [error, setError] = useState<string | null>(null);

  const { data: leads = [], isLoading, isError } = useQuery<Lead[]>({
    queryKey: ["/api/leads"],
  });

  const updateLeadStatusMutation = useMutation({
    mutationFn: async ({ leadId, status }: { leadId: number; status: LeadStatus }) => {
      const res = await apiRequest("PUT", `/api/leads/${leadId}`, { status });
      return await res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/leads"] });
    },
    onError: (error: Error) => {
      toast({
        title: "Erro ao mover lead",
        description: error.message,
        variant: "destructive",
      });
      setError(error.message);
    },
  });

  const handleDrop = (leadId: number, status: LeadStatus) => {
    updateLeadStatusMutation.mutate({ leadId, status });
  };

  if (isLoading) {
    return (
      <div className="flex justify-center items-center h-[60vh]">
        <Loader2 className="h-10 w-10 animate-spin text-primary" />
      </div>
    );
  }

  if (isError || error) {
    return (
      <Alert variant="destructive" className="mb-6">
        <AlertCircle className="h-4 w-4" />
        <AlertDescription>
          Erro ao carregar os leads. Por favor, tente novamente mais tarde.
        </AlertDescription>
      </Alert>
    );
  }

  const getLeadsByStatus = (status: LeadStatus) => {
    return leads.filter(lead => lead.status === status);
  };

  const statuses = leadStatusEnum.options;

  return (
    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-6 gap-4 overflow-x-auto pb-4">
      {statuses.map((status) => (
        <Column
          key={status}
          title={status}
          leads={getLeadsByStatus(status)}
          count={getLeadsByStatus(status).length}
          onDrop={handleDrop}
        />
      ))}
    </div>
  );
}
