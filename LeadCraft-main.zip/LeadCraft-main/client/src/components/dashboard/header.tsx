import { useState } from "react";
import { Button } from "@/components/ui/button";
import { useQuery } from "@tanstack/react-query";
import { Plus, AlertTriangle } from "lucide-react";
import { NewLeadDialog } from "./new-lead-dialog";
import { Progress } from "@/components/ui/progress";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { Link } from "wouter";

interface LeadCountData {
  count: number;
  limit: number;
  plan: string;
  percentage: number;
}

export function DashboardHeader() {
  const [isNewLeadDialogOpen, setIsNewLeadDialogOpen] = useState(false);

  const { data: leadCount } = useQuery<LeadCountData>({
    queryKey: ["/api/leads/count"],
  });

  return (
    <div className="mb-6 space-y-4">
      <div className="flex flex-col md:flex-row md:justify-between md:items-center gap-4">
        <div>
          <h1 className="text-2xl font-bold mb-1">Dashboard</h1>
          <p className="text-neutral-600">
            Gerencie seus leads de forma eficiente
          </p>
        </div>
        <Button onClick={() => setIsNewLeadDialogOpen(true)}>
          <Plus className="mr-2 h-4 w-4" /> Novo Lead
        </Button>
      </div>

      {leadCount && (
        <div className="p-4 border rounded-md bg-white">
          <div className="flex flex-col md:flex-row md:items-center md:justify-between mb-2">
            <div className="flex items-center">
              <p className="font-medium">
                Utilização do plano: {leadCount.count} de {leadCount.limit} leads
              </p>
              <span className="mx-2 text-neutral-300">|</span>
              <p className="text-sm text-neutral-600">
                Plano {leadCount.plan === "advanced" 
                  ? "Advanced" 
                  : leadCount.plan === "pro" 
                    ? "PRO" 
                    : "Gratuito"}
              </p>
            </div>
            {leadCount.plan === "free" && leadCount.percentage >= 70 && (
              <Link href="/settings">
                <Button size="sm" variant="outline" className="mt-2 md:mt-0">
                  Atualizar para PRO
                </Button>
              </Link>
            )}
            {leadCount.plan === "pro" && leadCount.percentage >= 70 && (
              <Link href="/settings">
                <Button size="sm" variant="outline" className="mt-2 md:mt-0" style={{ color: "#9333ea", borderColor: "#9333ea" }}>
                  Atualizar para Advanced
                </Button>
              </Link>
            )}
          </div>
          <Progress value={leadCount.percentage} className="h-2" />
          
          {leadCount.plan === "free" && leadCount.percentage >= 90 && (
            <div className="mt-2 rounded-lg border border-amber-200 bg-amber-50 p-4 text-amber-800">
              <div className="flex items-start">
                <AlertTriangle className="h-4 w-4 text-amber-600 mr-2 mt-0.5" />
                <div>
                  Você está próximo do limite de leads do plano gratuito. <Link href="/settings" className="font-medium underline">Atualize para o plano PRO</Link> para adicionar mais leads.
                </div>
              </div>
            </div>
          )}
          
          {leadCount.plan === "pro" && leadCount.percentage >= 90 && (
            <div className="mt-2 rounded-lg border border-purple-200 bg-purple-50 p-4 text-purple-800">
              <div className="flex items-start">
                <AlertTriangle className="h-4 w-4 text-purple-600 mr-2 mt-0.5" />
                <div>
                  Você está próximo do limite de leads do plano PRO. <Link href="/settings" className="font-medium underline" style={{color: "#9333ea"}}>Atualize para o plano Advanced</Link> para adicionar mais leads.
                </div>
              </div>
            </div>
          )}
        </div>
      )}

      <NewLeadDialog
        open={isNewLeadDialogOpen}
        onOpenChange={setIsNewLeadDialogOpen}
      />
    </div>
  );
}
