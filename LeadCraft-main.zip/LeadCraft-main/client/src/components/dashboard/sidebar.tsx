import { Link, useLocation } from "wouter";
import { ChartLine, LayoutDashboard, BarChart2, Settings, LogOut } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Separator } from "@/components/ui/separator";
import { useAuth } from "@/hooks/use-auth";

interface SidebarProps {
  closeSheet?: () => void;
}

export function Sidebar({ closeSheet }: SidebarProps) {
  const { user, logoutMutation } = useAuth();
  const [location] = useLocation();

  const handleLogout = () => {
    logoutMutation.mutate();
  };

  const NavLink = ({ href, children, icon }: { href: string; children: React.ReactNode; icon: React.ReactNode }) => (
    <Link href={href}>
      <Button 
        variant="ghost" 
        className="w-full justify-start" 
        onClick={closeSheet}
      >
        {icon}
        <span className="ml-2">{children}</span>
      </Button>
    </Link>
  );

  // Determinar a página atual para renderizar o link do logo apropriadamente
  const isAuthenticated = !!user;
  
  return (
    <div className="space-y-4 py-4">
      <div className="px-3 py-2">
        {/* Logo link - direciona para o dashboard quando autenticado */}
        <Link href={isAuthenticated ? "/dashboard" : "/"}>
          <div className="flex items-center mb-6 cursor-pointer">
            <ChartLine className="h-6 w-6 text-primary mr-2" />
            <h1 className="text-2xl font-bold text-primary">LeadUP</h1>
          </div>
        </Link>
        <div className="space-y-1">
          <NavLink href="/dashboard" icon={<LayoutDashboard className="h-5 w-5" />}>
            Dashboard
          </NavLink>
          <NavLink href="/reports" icon={<BarChart2 className="h-5 w-5" />}>
            Relatórios
          </NavLink>
          <NavLink href="/settings" icon={<Settings className="h-5 w-5" />}>
            Configurações
          </NavLink>
        </div>
      </div>
      <Separator />
      <div className="px-3 py-2">
        <div className="flex flex-col gap-1">
          <div className="px-3 py-2">
            <p className="text-sm font-medium">{user?.name}</p>
            <p className="text-xs text-neutral-500">{user?.email}</p>
          </div>
          <Button 
            variant="ghost" 
            className="w-full justify-start text-red-500 hover:text-red-600 hover:bg-red-50"
            onClick={handleLogout}
            disabled={logoutMutation.isPending}
          >
            <LogOut className="h-5 w-5 mr-2" />
            {logoutMutation.isPending ? "Saindo..." : "Sair"}
          </Button>
        </div>
      </div>
    </div>
  );
}