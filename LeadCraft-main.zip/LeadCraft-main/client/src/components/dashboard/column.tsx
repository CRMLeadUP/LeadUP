import { useState } from "react";
import { Badge } from "@/components/ui/badge";
import { Lead, LeadStatus } from "@shared/schema";
import { LeadCard } from "./lead-card";
import { cn } from "@/lib/utils";

interface ColumnProps {
  title: LeadStatus;
  leads: Lead[];
  count: number;
  onDrop: (leadId: number, status: LeadStatus) => void;
}

export function Column({ title, leads, count, onDrop }: ColumnProps) {
  const [isOver, setIsOver] = useState(false);
  
  const handleDragOver = (e: React.DragEvent) => {
    e.preventDefault();
    setIsOver(true);
  };

  const handleDragLeave = () => {
    setIsOver(false);
  };

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    setIsOver(false);
    
    const leadId = Number(e.dataTransfer.getData("leadId"));
    if (leadId) {
      onDrop(leadId, title);
    }
  };

  const handleDragStart = (e: React.DragEvent, lead: Lead) => {
    e.dataTransfer.setData("leadId", lead.id.toString());
    e.dataTransfer.effectAllowed = "move";
  };

  return (
    <div
      className={cn(
        "bg-neutral-100 p-4 rounded-lg min-h-[500px] w-full flex flex-col",
        isOver ? "column-highlight" : ""
      )}
      onDragOver={handleDragOver}
      onDragLeave={handleDragLeave}
      onDrop={handleDrop}
    >
      <div className="flex justify-between items-center mb-4">
        <h3 className="font-semibold">{title}</h3>
        <Badge variant="secondary" className="bg-neutral-200 text-neutral-700">
          {count}
        </Badge>
      </div>
      
      <div className="space-y-3 flex-grow">
        {leads.length === 0 ? (
          <div className="text-center p-4 text-neutral-500 text-sm border border-dashed border-neutral-300 rounded-md h-20 flex items-center justify-center bg-white/50">
            Arraste leads para esta coluna
          </div>
        ) : (
          leads.map((lead) => (
            <LeadCard
              key={lead.id}
              lead={lead}
              onDragStart={handleDragStart}
            />
          ))
        )}
      </div>
    </div>
  );
}
