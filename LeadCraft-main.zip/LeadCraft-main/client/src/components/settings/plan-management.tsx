import { useState } from "react";
import { useMutation, useQuery } from "@tanstack/react-query";
import { Check, CreditCard, Loader2 } from "lucide-react";
import { useAuth } from "@/hooks/use-auth";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { formatCurrency } from "@/lib/utils";
import { Progress } from "@/components/ui/progress";
import { UserPlan } from "@shared/schema";
import { AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent, AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle } from "@/components/ui/alert-dialog";

interface LeadCountData {
  count: number;
  limit: number;
  plan: string;
  percentage: number;
}

export function PlanManagement() {
  const { toast } = useToast();
  const { user } = useAuth();
  const [showProConfirmation, setShowProConfirmation] = useState(false);
  const [showAdvancedConfirmation, setShowAdvancedConfirmation] = useState(false);
  const [showFreeConfirmation, setShowFreeConfirmation] = useState(false);
  
  const { data: plan } = useQuery<UserPlan>({
    queryKey: ["/api/user/plan"],
  });

  const { data: leadCount } = useQuery<LeadCountData>({
    queryKey: ["/api/leads/count"],
  });

  const updatePlanMutation = useMutation({
    mutationFn: async ({ plan }: { plan: string }) => {
      const res = await apiRequest("POST", "/api/user/plan", { plan });
      return await res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/user"] });
      queryClient.invalidateQueries({ queryKey: ["/api/user/plan"] });
      queryClient.invalidateQueries({ queryKey: ["/api/leads/count"] });
      
      toast({
        title: "Plano atualizado",
        description: "Seu plano foi atualizado com sucesso!",
      });
    },
    onError: (error: Error) => {
      toast({
        title: "Erro ao atualizar plano",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  const handleUpgradeToPro = () => {
    if (user?.plan === "pro") {
      toast({
        title: "Você já está no plano PRO",
        description: "Aproveite todas as funcionalidades disponíveis.",
      });
      return;
    }
    
    setShowProConfirmation(true);
  };
  
  const handleUpgradeToAdvanced = () => {
    if (user?.plan === "advanced") {
      toast({
        title: "Você já está no plano Advanced",
        description: "Aproveite todas as funcionalidades premium disponíveis.",
      });
      return;
    }
    
    setShowAdvancedConfirmation(true);
  };

  const handleDowngradeToFree = () => {
    if (user?.plan === "free") {
      toast({
        title: "Você já está no plano Gratuito",
        description: "Você pode fazer upgrade para outro plano a qualquer momento.",
      });
      return;
    }
    
    // Check if lead count exceeds free plan limit
    if (leadCount && leadCount.count > 10) {
      toast({
        title: "Não é possível fazer downgrade",
        description: "Você precisa ter no máximo 10 leads para fazer downgrade para o plano gratuito.",
        variant: "destructive",
      });
      return;
    }
    
    setShowFreeConfirmation(true);
  };

  const confirmUpgradeToPro = () => {
    updatePlanMutation.mutate({ plan: "pro" });
    setShowProConfirmation(false);
  };
  
  const confirmUpgradeToAdvanced = () => {
    updatePlanMutation.mutate({ plan: "advanced" });
    setShowAdvancedConfirmation(false);
  };

  const confirmDowngradeToFree = () => {
    updatePlanMutation.mutate({ plan: "free" });
    setShowFreeConfirmation(false);
  };

  const isPro = user?.plan === "pro";
  const isAdvanced = user?.plan === "advanced";

  return (
    <>
      <Card>
        <CardHeader>
          <CardTitle>Gerenciamento de Plano</CardTitle>
          <CardDescription>
            Gerencie seu plano de assinatura e veja os limites de uso
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="space-y-6">
            <div>
              <h3 className="text-lg font-medium mb-2">Seu plano atual</h3>
              <div className="p-4 bg-primary/5 rounded-md border border-primary/20">
                <div className="flex items-center">
                  <div className="mr-4 bg-primary/10 p-2 rounded-full">
                    <CreditCard className="h-6 w-6 text-primary" />
                  </div>
                  <div>
                    <h4 className="font-medium text-lg">
                      {isAdvanced 
                        ? "Plano Advanced" 
                        : isPro 
                          ? "Plano PRO" 
                          : "Plano Gratuito"}
                    </h4>
                    <p className="text-sm text-neutral-600">
                      {isAdvanced
                        ? `${formatCurrency(49.9)} / mês - Até 999 leads`
                        : isPro 
                          ? `${formatCurrency(19.9)} / mês - Até 300 leads` 
                          : "Grátis - Até 10 leads"}
                    </p>
                  </div>
                </div>
              </div>
            </div>

            {leadCount && (
              <div>
                <div className="flex justify-between mb-2">
                  <h3 className="font-medium">Utilização de leads</h3>
                  <span className="text-sm text-neutral-600">
                    {leadCount.count} de {leadCount.limit} leads
                  </span>
                </div>
                <Progress value={leadCount.percentage} className="h-2 mb-1" />
                <p className="text-xs text-neutral-500 mt-1">
                  {leadCount.percentage >= 90 
                    ? "Você está próximo do limite do seu plano" 
                    : "Você ainda tem espaço para adicionar mais leads"}
                </p>
              </div>
            )}
            
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              <Card className={isAdvanced ? "border-2 border-purple-500" : ""}>
                <CardHeader className="pb-2">
                  <CardTitle className="text-xl">Plano Advanced</CardTitle>
                  <CardDescription>
                    {formatCurrency(49.9)}/mês
                  </CardDescription>
                </CardHeader>
                <CardContent className="pt-0 pb-2">
                  <ul className="space-y-2 mt-2">
                    <li className="flex items-center">
                      <Check className="h-4 w-4 text-green-500 mr-2" />
                      <span>Até 999 leads</span>
                    </li>
                    <li className="flex items-center">
                      <Check className="h-4 w-4 text-green-500 mr-2" />
                      <span>Estatísticas premium</span>
                    </li>
                    <li className="flex items-center">
                      <Check className="h-4 w-4 text-green-500 mr-2" />
                      <span>Suporte premium 24/7</span>
                    </li>
                    <li className="flex items-center">
                      <Check className="h-4 w-4 text-green-500 mr-2" />
                      <span>Integração com WhatsApp</span>
                    </li>
                    <li className="flex items-center">
                      <Check className="h-4 w-4 text-green-500 mr-2" />
                      <span>Exportação avançada</span>
                    </li>
                    <li className="flex items-center">
                      <Check className="h-4 w-4 text-green-500 mr-2" />
                      <span>API para integrações</span>
                    </li>
                  </ul>
                </CardContent>
                <CardFooter>
                  <Button 
                    className="w-full" 
                    onClick={handleUpgradeToAdvanced}
                    disabled={isAdvanced || updatePlanMutation.isPending}
                    variant={isAdvanced ? "outline" : "default"}
                  >
                    {updatePlanMutation.isPending ? (
                      <>
                        <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                        Processando...
                      </>
                    ) : isAdvanced ? "Plano Atual" : "Fazer Upgrade"}
                  </Button>
                </CardFooter>
              </Card>

              <Card className={isPro && !isAdvanced ? "border-2 border-primary" : ""}>
                <CardHeader className="pb-2">
                  <CardTitle className="text-xl">Plano PRO</CardTitle>
                  <CardDescription>
                    {formatCurrency(19.9)}/mês
                  </CardDescription>
                </CardHeader>
                <CardContent className="pt-0 pb-2">
                  <ul className="space-y-2 mt-2">
                    <li className="flex items-center">
                      <Check className="h-4 w-4 text-green-500 mr-2" />
                      <span>Até 300 leads</span>
                    </li>
                    <li className="flex items-center">
                      <Check className="h-4 w-4 text-green-500 mr-2" />
                      <span>Estatísticas avançadas</span>
                    </li>
                    <li className="flex items-center">
                      <Check className="h-4 w-4 text-green-500 mr-2" />
                      <span>Suporte prioritário</span>
                    </li>
                    <li className="flex items-center">
                      <Check className="h-4 w-4 text-green-500 mr-2" />
                      <span>Integração com WhatsApp</span>
                    </li>
                    <li className="flex items-center">
                      <Check className="h-4 w-4 text-green-500 mr-2" />
                      <span>Exportação de relatórios</span>
                    </li>
                  </ul>
                </CardContent>
                <CardFooter>
                  <Button 
                    className="w-full" 
                    onClick={handleUpgradeToPro}
                    disabled={(isPro && !isAdvanced) || updatePlanMutation.isPending}
                    variant={(isPro && !isAdvanced) ? "outline" : "default"}
                  >
                    {updatePlanMutation.isPending ? (
                      <>
                        <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                        Processando...
                      </>
                    ) : (isPro && !isAdvanced) ? "Plano Atual" : "Fazer Upgrade"}
                  </Button>
                </CardFooter>
              </Card>

              <Card className={!isPro && !isAdvanced ? "border-2 border-gray-300" : ""}>
                <CardHeader className="pb-2">
                  <CardTitle className="text-xl">Plano Gratuito</CardTitle>
                  <CardDescription>
                    {formatCurrency(0)}/mês
                  </CardDescription>
                </CardHeader>
                <CardContent className="pt-0 pb-2">
                  <ul className="space-y-2 mt-2">
                    <li className="flex items-center">
                      <Check className="h-4 w-4 text-green-500 mr-2" />
                      <span>Até 10 leads</span>
                    </li>
                    <li className="flex items-center">
                      <Check className="h-4 w-4 text-green-500 mr-2" />
                      <span>Estatísticas básicas</span>
                    </li>
                    <li className="flex items-center">
                      <Check className="h-4 w-4 text-green-500 mr-2" />
                      <span>Gerenciamento de leads</span>
                    </li>
                    <li className="flex items-center">
                      <Check className="h-4 w-4 text-green-500 mr-2" />
                      <span>Suporte por email</span>
                    </li>
                  </ul>
                </CardContent>
                <CardFooter>
                  <Button 
                    variant="outline" 
                    className="w-full" 
                    onClick={handleDowngradeToFree}
                    disabled={(!isPro && !isAdvanced) || updatePlanMutation.isPending}
                  >
                    {updatePlanMutation.isPending ? (
                      <>
                        <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                        Processando...
                      </>
                    ) : (!isPro && !isAdvanced) ? "Plano Atual" : "Fazer Downgrade"}
                  </Button>
                </CardFooter>
              </Card>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* PRO Plan Confirmation Dialog */}
      <AlertDialog open={showProConfirmation} onOpenChange={setShowProConfirmation}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Fazer Upgrade para o Plano PRO</AlertDialogTitle>
            <AlertDialogDescription>
              Você está prestes a fazer upgrade para o plano PRO por {formatCurrency(19.9)}/mês.
              Você terá acesso a todas as funcionalidades avançadas e poderá gerenciar até 300 leads.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Cancelar</AlertDialogCancel>
            <AlertDialogAction onClick={confirmUpgradeToPro}>
              Confirmar Upgrade
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>

      {/* Advanced Plan Confirmation Dialog */}
      <AlertDialog open={showAdvancedConfirmation} onOpenChange={setShowAdvancedConfirmation}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Fazer Upgrade para o Plano Advanced</AlertDialogTitle>
            <AlertDialogDescription>
              Você está prestes a fazer upgrade para o plano Advanced por {formatCurrency(49.9)}/mês.
              Você terá acesso a todas as funcionalidades premium e poderá gerenciar até 999 leads.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Cancelar</AlertDialogCancel>
            <AlertDialogAction onClick={confirmUpgradeToAdvanced}>
              Confirmar Upgrade
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>

      {/* Free Plan Confirmation Dialog */}
      <AlertDialog open={showFreeConfirmation} onOpenChange={setShowFreeConfirmation}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Fazer Downgrade para o Plano Gratuito</AlertDialogTitle>
            <AlertDialogDescription>
              Você está prestes a fazer downgrade para o plano gratuito.
              Você terá acesso apenas às funcionalidades básicas e poderá gerenciar até 10 leads.
              {leadCount && leadCount.count > 0 && (
                <div className="mt-2">
                  Atualmente você possui {leadCount.count} lead{leadCount.count !== 1 ? 's' : ''}.
                </div>
              )}
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Cancelar</AlertDialogCancel>
            <AlertDialogAction onClick={confirmDowngradeToFree}>
              Confirmar Downgrade
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </>
  );
}
