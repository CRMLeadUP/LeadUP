import { useState, useEffect } from "react";
import { DashboardHeader } from "@/components/dashboard/header";
import { Board } from "@/components/dashboard/board";
import { ChartLine } from "lucide-react";
import { Sheet, SheetContent, SheetTrigger } from "@/components/ui/sheet";
import { Button } from "@/components/ui/button";
import { useIsMobile as useMobile } from "@/hooks/use-mobile";
import { Sidebar } from "@/components/dashboard/sidebar";
import { Link } from "wouter";

export default function DashboardPage() {
  const isMobile = useMobile();
  const [openSheet, setOpenSheet] = useState(false);

  useEffect(() => {
    // Set document title
    document.title = "Dashboard | LeadUP";
  }, []);

  return (
    <div className="min-h-screen bg-neutral-50 flex">
      {/* Sidebar for desktop */}
      {!isMobile && (
        <div className="hidden md:flex flex-col w-64 bg-white border-r border-neutral-200">
          <Sidebar />
        </div>
      )}

      {/* Main content */}
      <div className="flex-1 flex flex-col overflow-hidden">
        {/* Top navigation for mobile */}
        {isMobile && (
          <div className="bg-white border-b border-neutral-200 p-4 flex items-center justify-between">
            <Link href="/dashboard">
              <div className="flex items-center">
                <ChartLine className="h-6 w-6 text-primary mr-2" />
                <h1 className="text-xl font-bold text-primary">LeadUP</h1>
              </div>
            </Link>

            <Sheet open={openSheet} onOpenChange={setOpenSheet}>
              <SheetTrigger asChild>
                <Button variant="ghost" size="icon">
                  <svg
                    xmlns="http://www.w3.org/2000/svg"
                    className="h-6 w-6"
                    fill="none"
                    viewBox="0 0 24 24"
                    stroke="currentColor"
                  >
                    <path
                      strokeLinecap="round"
                      strokeLinejoin="round"
                      strokeWidth={2}
                      d="M4 6h16M4 12h16M4 18h16"
                    />
                  </svg>
                </Button>
              </SheetTrigger>
              <SheetContent side="left" className="w-64 p-0">
                <Sidebar closeSheet={() => setOpenSheet(false)} />
              </SheetContent>
            </Sheet>
          </div>
        )}

        {/* Dashboard content */}
        <div className="flex-1 overflow-auto p-6">
          <DashboardHeader />
          <Board />
        </div>
      </div>
    </div>
  );
}
