import { useState, useEffect } from "react";
import { Link } from "wouter";
import { ChartLine } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Sheet, SheetContent, SheetTrigger } from "@/components/ui/sheet";
import { useIsMobile as useMobile } from "@/hooks/use-mobile";
import { LeadSummary } from "@/components/reports/lead-summary";
import { ActivitySummary } from "@/components/reports/activity-summary";
import { Sidebar } from "@/components/dashboard/sidebar";

export default function ReportsPage() {
  const isMobile = useMobile();
  const [openSheet, setOpenSheet] = useState(false);

  useEffect(() => {
    // Set document title
    document.title = "Relatórios | LeadUP";
  }, []);

  return (
    <div className="min-h-screen bg-neutral-50 flex">
      {/* Sidebar for desktop */}
      {!isMobile && (
        <div className="hidden md:flex flex-col w-64 bg-white border-r border-neutral-200">
          <Sidebar />
        </div>
      )}

      {/* Main content */}
      <div className="flex-1 flex flex-col overflow-hidden">
        {/* Top navigation for mobile */}
        {isMobile && (
          <div className="bg-white border-b border-neutral-200 p-4 flex items-center justify-between">
            <Link href="/dashboard">
              <div className="flex items-center">
                <ChartLine className="h-6 w-6 text-primary mr-2" />
                <h1 className="text-xl font-bold text-primary">LeadUP</h1>
              </div>
            </Link>

            <Sheet open={openSheet} onOpenChange={setOpenSheet}>
              <SheetTrigger asChild>
                <Button variant="ghost" size="icon">
                  <svg
                    xmlns="http://www.w3.org/2000/svg"
                    className="h-6 w-6"
                    fill="none"
                    viewBox="0 0 24 24"
                    stroke="currentColor"
                  >
                    <path
                      strokeLinecap="round"
                      strokeLinejoin="round"
                      strokeWidth={2}
                      d="M4 6h16M4 12h16M4 18h16"
                    />
                  </svg>
                </Button>
              </SheetTrigger>
              <SheetContent side="left" className="w-64 p-0">
                <Sidebar closeSheet={() => setOpenSheet(false)} />
              </SheetContent>
            </Sheet>
          </div>
        )}

        {/* Reports content */}
        <div className="flex-1 overflow-auto p-6">
          <div className="mb-6">
            <h1 className="text-2xl font-bold mb-1">Relatórios</h1>
            <p className="text-neutral-600">
              Acompanhe o desempenho dos seus leads e atividades
            </p>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 mb-6">
            <LeadSummary />
            <ActivitySummary />
          </div>
        </div>
      </div>
    </div>
  );
}
