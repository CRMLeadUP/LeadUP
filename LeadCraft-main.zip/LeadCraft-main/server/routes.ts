import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { setupAuth } from "./auth";
import { leadStatusEnum, userPlanEnum } from "@shared/schema";
import { eq } from "drizzle-orm";

export async function registerRoutes(app: Express): Promise<Server> {
  // Auth routes
  setupAuth(app);

  // Lead management routes
  app.get("/api/leads", async (req, res, next) => {
    try {
      if (!req.isAuthenticated()) return res.status(401).json({ message: "Não autenticado" });
      
      const userId = req.user!.id;
      const leads = await storage.getLeadsByUserId(userId);
      res.json(leads);
    } catch (error) {
      next(error);
    }
  });

  app.post("/api/leads", async (req, res, next) => {
    try {
      if (!req.isAuthenticated()) return res.status(401).json({ message: "Não autenticado" });
      
      const userId = req.user!.id;
      const leadCount = await storage.getLeadCountByUserId(userId);
      
      // Check lead limits based on plan
      const getPlanLimit = (plan: string) => {
        if (plan === "advanced") return 999;
        if (plan === "pro") return 300;
        return 10; // free plan
      };
      
      const planLimit = getPlanLimit(req.user!.plan);
      if (leadCount >= planLimit) {
        return res.status(403).json({ 
          message: "Limite de leads atingido",
          plan: req.user!.plan,
          limit: planLimit
        });
      }
      
      const newLead = await storage.createLead({
        ...req.body,
        userId,
      });
      
      res.status(201).json(newLead);
    } catch (error) {
      next(error);
    }
  });

  app.put("/api/leads/:id", async (req, res, next) => {
    try {
      if (!req.isAuthenticated()) return res.status(401).json({ message: "Não autenticado" });
      
      const leadId = parseInt(req.params.id);
      const lead = await storage.getLead(leadId);
      
      if (!lead) {
        return res.status(404).json({ message: "Lead não encontrado" });
      }
      
      if (lead.userId !== req.user!.id) {
        return res.status(403).json({ message: "Você não tem permissão para atualizar este lead" });
      }
      
      // Validate lead status if present
      if (req.body.status && !leadStatusEnum.safeParse(req.body.status).success) {
        return res.status(400).json({ message: "Status de lead inválido" });
      }
      
      const updatedLead = await storage.updateLead(leadId, req.body);
      res.json(updatedLead);
    } catch (error) {
      next(error);
    }
  });

  app.delete("/api/leads/:id", async (req, res, next) => {
    try {
      if (!req.isAuthenticated()) return res.status(401).json({ message: "Não autenticado" });
      
      const leadId = parseInt(req.params.id);
      const lead = await storage.getLead(leadId);
      
      if (!lead) {
        return res.status(404).json({ message: "Lead não encontrado" });
      }
      
      if (lead.userId !== req.user!.id) {
        return res.status(403).json({ message: "Você não tem permissão para excluir este lead" });
      }
      
      await storage.deleteLead(leadId);
      res.status(204).send();
    } catch (error) {
      next(error);
    }
  });

  // User plan management routes
  app.get("/api/user/plan", async (req, res, next) => {
    try {
      if (!req.isAuthenticated()) return res.status(401).json({ message: "Não autenticado" });
      
      const userId = req.user!.id;
      const plan = await storage.getUserPlan(userId);
      res.json(plan || { plan: "free" });
    } catch (error) {
      next(error);
    }
  });

  app.post("/api/user/plan", async (req, res, next) => {
    try {
      if (!req.isAuthenticated()) return res.status(401).json({ message: "Não autenticado" });
      
      const userId = req.user!.id;
      
      // Validate plan type
      if (!userPlanEnum.safeParse(req.body.plan).success) {
        return res.status(400).json({ message: "Tipo de plano inválido" });
      }
      
      const newPlan = await storage.createUserPlan({
        userId,
        plan: req.body.plan,
        active: true
      });
      
      // Update user's plan field too for quick access
      await storage.updateUser(userId, { plan: req.body.plan });
      
      res.status(201).json(newPlan);
    } catch (error) {
      next(error);
    }
  });

  // User update route
  app.put("/api/user", async (req, res, next) => {
    try {
      if (!req.isAuthenticated()) return res.status(401).json({ message: "Não autenticado" });
      
      const userId = req.user!.id;
      const updateData = { ...req.body };
      
      // Prevent updating critical fields directly
      delete updateData.id;
      delete updateData.password;
      
      const updatedUser = await storage.updateUser(userId, updateData);
      res.json(updatedUser);
    } catch (error) {
      next(error);
    }
  });
  
  // Password update route
  app.put("/api/user/password", async (req, res, next) => {
    try {
      if (!req.isAuthenticated()) return res.status(401).json({ message: "Não autenticado" });
      
      const userId = req.user!.id;
      const { currentPassword, newPassword } = req.body;
      
      if (!currentPassword || !newPassword) {
        return res.status(400).json({ message: "Senhas atuais e novas são necessárias" });
      }
      
      const user = await storage.getUser(userId);
      if (!user) {
        return res.status(404).json({ message: "Usuário não encontrado" });
      }
      
      // Verify current password
      const isCorrectPassword = await comparePasswords(currentPassword, user.password);
      if (!isCorrectPassword) {
        return res.status(403).json({ message: "Senha atual incorreta" });
      }
      
      // Hash new password
      const hashedPassword = await hashPassword(newPassword);
      
      // Update password
      await storage.updateUser(userId, { password: hashedPassword });
      
      res.status(200).json({ message: "Senha atualizada com sucesso" });
    } catch (error) {
      next(error);
    }
  });

  // Reports routes
  app.get("/api/reports/summary", async (req, res, next) => {
    try {
      if (!req.isAuthenticated()) return res.status(401).json({ message: "Não autenticado" });
      
      const userId = req.user!.id;
      const leads = await storage.getLeadsByUserId(userId);
      
      // Group leads by status
      const byStatus = leads.reduce((acc, lead) => {
        acc[lead.status] = (acc[lead.status] || 0) + 1;
        return acc;
      }, {} as Record<string, number>);
      
      // For all possible statuses, ensure they have a value
      const statuses = leadStatusEnum.options;
      const summary = statuses.reduce((acc, status) => {
        acc[status] = byStatus[status] || 0;
        return acc;
      }, {} as Record<string, number>);
      
      res.json({ 
        total: leads.length,
        byStatus: summary
      });
    } catch (error) {
      next(error);
    }
  });

  // Lead count endpoint for plan limit checking
  app.get("/api/leads/count", async (req, res, next) => {
    try {
      if (!req.isAuthenticated()) return res.status(401).json({ message: "Não autenticado" });
      
      const userId = req.user!.id;
      const count = await storage.getLeadCountByUserId(userId);
      
      const getPlanLimit = (plan: string) => {
        if (plan === "advanced") return 999;
        if (plan === "pro") return 300;
        return 10; // free plan
      };
      
      const planLimit = getPlanLimit(req.user!.plan);
      
      res.json({ 
        count,
        limit: planLimit,
        plan: req.user!.plan,
        percentage: Math.round((count / planLimit) * 100)
      });
    } catch (error) {
      next(error);
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}

// Helper functions
async function hashPassword(password: string) {
  const salt = randomBytes(16).toString("hex");
  const buf = (await promisify(scrypt)(password, salt, 64)) as Buffer;
  return `${buf.toString("hex")}.${salt}`;
}

async function comparePasswords(supplied: string, stored: string) {
  const [hashed, salt] = stored.split(".");
  const hashedBuf = Buffer.from(hashed, "hex");
  const suppliedBuf = (await promisify(scrypt)(supplied, salt, 64)) as Buffer;
  return timingSafeEqual(hashedBuf, suppliedBuf);
}

import { randomBytes, scrypt, timingSafeEqual } from "crypto";
import { promisify } from "util";
