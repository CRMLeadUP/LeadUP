import { 
  users, leads, userPlans,
  type User, type InsertUser,
  type Lead, type InsertLead,
  type UserPlan, type InsertUserPlan
} from "@shared/schema";
import { db } from "./db";
import { eq, and, count, sql } from "drizzle-orm";
import session from "express-session";
import createMemoryStore from "memorystore";

const MemoryStore = createMemoryStore(session);

export interface IStorage {
  // User methods
  getUser(id: number): Promise<User | undefined>;
  getUserByEmail(email: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  updateUser(id: number, user: Partial<User>): Promise<User | undefined>;
  
  // Lead methods
  getLead(id: number): Promise<Lead | undefined>;
  getLeadsByUserId(userId: number): Promise<Lead[]>;
  createLead(lead: InsertLead): Promise<Lead>;
  updateLead(id: number, lead: Partial<Lead>): Promise<Lead | undefined>;
  deleteLead(id: number): Promise<void>;
  getLeadCountByUserId(userId: number): Promise<number>;
  
  // UserPlan methods
  getUserPlan(userId: number): Promise<UserPlan | undefined>;
  createUserPlan(userPlan: InsertUserPlan): Promise<UserPlan>;
  updateUserPlan(userId: number, userPlan: Partial<UserPlan>): Promise<UserPlan | undefined>;
  
  // Session store
  sessionStore: any; // Usar any para evitar problemas de tipo
}

export class DatabaseStorage implements IStorage {
  sessionStore: any; // Usar any para evitar problemas de tipo

  constructor() {
    this.sessionStore = new MemoryStore({
      checkPeriod: 86400000,
    });
  }

  // User methods
  async getUser(id: number): Promise<User | undefined> {
    try {
      const [user] = await db.select().from(users).where(eq(users.id, id));
      return user;
    } catch (error) {
      console.error('Erro ao buscar usuário por ID:', error);
      throw new Error(`Falha ao buscar usuário: ${(error as Error).message}`);
    }
  }

  async getUserByEmail(email: string): Promise<User | undefined> {
    try {
      const [user] = await db.select().from(users).where(eq(users.email, email));
      return user;
    } catch (error) {
      console.error('Erro ao buscar usuário por email:', error);
      throw new Error(`Falha ao buscar usuário: ${(error as Error).message}`);
    }
  }

  async createUser(user: InsertUser): Promise<User> {
    try {
      const [newUser] = await db.insert(users).values(user).returning();
      return newUser;
    } catch (error) {
      console.error('Erro ao criar novo usuário:', error);
      throw new Error(`Falha ao criar usuário: ${(error as Error).message}`);
    }
  }

  async updateUser(id: number, userData: Partial<User>): Promise<User | undefined> {
    const [updatedUser] = await db
      .update(users)
      .set({
        ...userData,
        ...(userData.plan ? { plan: userData.plan } : {})
      })
      .where(eq(users.id, id))
      .returning();
    return updatedUser;
  }

  // Lead methods
  async getLead(id: number): Promise<Lead | undefined> {
    const [lead] = await db.select().from(leads).where(eq(leads.id, id));
    return lead;
  }

  async getLeadsByUserId(userId: number): Promise<Lead[]> {
    return db.select().from(leads).where(eq(leads.userId, userId));
  }

  async createLead(lead: InsertLead): Promise<Lead> {
    const [newLead] = await db.insert(leads).values(lead).returning();
    return newLead;
  }

  async updateLead(id: number, leadData: Partial<Lead>): Promise<Lead | undefined> {
    const [updatedLead] = await db
      .update(leads)
      .set({
        ...leadData,
        updatedAt: new Date()
      })
      .where(eq(leads.id, id))
      .returning();
    return updatedLead;
  }

  async deleteLead(id: number): Promise<void> {
    await db.delete(leads).where(eq(leads.id, id));
  }

  async getLeadCountByUserId(userId: number): Promise<number> {
    const [result] = await db
      .select({ count: count() })
      .from(leads)
      .where(eq(leads.userId, userId));
    return result.count;
  }

  // UserPlan methods
  async getUserPlan(userId: number): Promise<UserPlan | undefined> {
    const [plan] = await db
      .select()
      .from(userPlans)
      .where(and(
        eq(userPlans.userId, userId),
        eq(userPlans.active, true)
      ))
      .limit(1);
    return plan;
  }

  async createUserPlan(userPlan: InsertUserPlan): Promise<UserPlan> {
    try {
      // Deactivate any existing plans for this user
      try {
        await db
          .update(userPlans)
          .set({ active: false })
          .where(eq(userPlans.userId, userPlan.userId));
      } catch (deactivateError) {
        console.error('Erro ao desativar planos existentes:', deactivateError);
        // Continua mesmo se falhar a desativação
      }
      
      const [newPlan] = await db.insert(userPlans).values(userPlan).returning();
      return newPlan;
    } catch (error) {
      console.error('Erro ao criar plano de usuário:', error);
      throw new Error(`Falha ao criar plano: ${(error as Error).message}`);
    }
  }

  async updateUserPlan(userId: number, planData: Partial<UserPlan>): Promise<UserPlan | undefined> {
    const [updatedPlan] = await db
      .update(userPlans)
      .set({
        ...planData,
        updatedAt: new Date()
      })
      .where(and(
        eq(userPlans.userId, userId),
        eq(userPlans.active, true)
      ))
      .returning();
    return updatedPlan;
  }
}

export const storage = new DatabaseStorage();
