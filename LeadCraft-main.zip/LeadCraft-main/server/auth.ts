import passport from "passport";
import { Strategy as LocalStrategy } from "passport-local";
import { Express } from "express";
import session from "express-session";
import { scrypt, randomBytes, timingSafeEqual } from "crypto";
import { promisify } from "util";
import { storage } from "./storage";
import { User as SelectUser } from "@shared/schema";

declare global {
  namespace Express {
    interface User extends SelectUser {}
  }
}

const scryptAsync = promisify(scrypt);

async function hashPassword(password: string) {
  const salt = randomBytes(16).toString("hex");
  const buf = (await scryptAsync(password, salt, 64)) as Buffer;
  return `${buf.toString("hex")}.${salt}`;
}

async function comparePasswords(supplied: string, stored: string) {
  const [hashed, salt] = stored.split(".");
  const hashedBuf = Buffer.from(hashed, "hex");
  const suppliedBuf = (await scryptAsync(supplied, salt, 64)) as Buffer;
  return timingSafeEqual(hashedBuf, suppliedBuf);
}

export function setupAuth(app: Express) {
  const sessionSettings: session.SessionOptions = {
    secret: process.env.SESSION_SECRET || "leadup-secret-key",
    resave: false,
    saveUninitialized: false,
    store: storage.sessionStore,
    cookie: {
      secure: process.env.NODE_ENV === "production",
      maxAge: 1000 * 60 * 60 * 24 * 7, // 1 week
    }
  };

  app.set("trust proxy", 1);
  app.use(session(sessionSettings));
  app.use(passport.initialize());
  app.use(passport.session());

  passport.use(
    new LocalStrategy({ usernameField: 'email' }, async (email, password, done) => {
      try {
        const user = await storage.getUserByEmail(email);
        if (!user || !(await comparePasswords(password, user.password))) {
          return done(null, false, { message: "Credenciais inválidas" });
        } else {
          return done(null, user);
        }
      } catch (err) {
        return done(err);
      }
    }),
  );

  passport.serializeUser((user, done) => done(null, user.id));
  passport.deserializeUser(async (id: number, done) => {
    try {
      const user = await storage.getUser(id);
      done(null, user);
    } catch (err) {
      done(err);
    }
  });

  app.post("/api/register", async (req, res, next) => {
    try {
      console.log("Tentativa de registro:", req.body.email);
      
      try {
        const existingUser = await storage.getUserByEmail(req.body.email);
        if (existingUser) {
          console.log("Usuário já existe:", req.body.email);
          return res.status(400).json({ message: "Usuário já existe" });
        }
      } catch (error) {
        console.error("Erro ao verificar usuário existente:", error);
        // Continua o fluxo mesmo com erro na verificação
      }

      try {
        const hashedPassword = await hashPassword(req.body.password);
        
        const user = await storage.createUser({
          ...req.body,
          password: hashedPassword,
        });

        console.log("Usuário criado com sucesso:", user.id);

        // Create a default user plan entry
        try {
          await storage.createUserPlan({
            userId: user.id,
            plan: "free",
            active: true
          });
          console.log("Plano do usuário criado com sucesso");
        } catch (planError) {
          console.error("Erro ao criar plano do usuário:", planError);
          // Continua mesmo com erro no plano
        }

        req.login(user, (err) => {
          if (err) {
            console.error("Erro no login após registro:", err);
            return next(err);
          }
          console.log("Login após registro bem-sucedido");
          return res.status(201).json(user);
        });
      } catch (createError) {
        console.error("Erro ao criar usuário:", createError);
        return res.status(500).json({ message: "Erro ao criar usuário", error: createError.message });
      }
    } catch (error) {
      console.error("Erro geral no registro:", error);
      res.status(500).json({ message: "Erro interno no servidor", error: error.message });
    }
  });

  app.post("/api/login", (req, res, next) => {
    console.log("Tentativa de login:", req.body.email);
    
    passport.authenticate("local", (err, user, info) => {
      if (err) {
        console.error("Erro na autenticação:", err);
        return res.status(500).json({ message: "Erro ao realizar login", error: err.message });
      }
      
      if (!user) {
        console.log("Login falhou - usuário não encontrado ou senha incorreta");
        return res.status(401).json({ message: info?.message || "Credenciais inválidas" });
      }
      
      console.log("Usuário autenticado com sucesso:", user.id);
      
      req.login(user, (loginErr) => {
        if (loginErr) {
          console.error("Erro ao criar sessão:", loginErr);
          return res.status(500).json({ message: "Erro ao iniciar sessão", error: loginErr.message });
        }
        
        console.log("Sessão iniciada com sucesso");
        return res.status(200).json(user);
      });
    })(req, res, next);
  });

  app.post("/api/logout", (req, res, next) => {
    req.logout((err) => {
      if (err) return next(err);
      res.sendStatus(200);
    });
  });

  app.get("/api/user", (req, res) => {
    if (!req.isAuthenticated()) return res.sendStatus(401);
    res.json(req.user);
  });
}
import pg from 'pg';
const { Pool } = pg;

const pool = new Pool({
    connectionString: process.env.DATABASE_URL, // Verifica se a variável está sendo usada aqui
    ssl: {
        rejectUnauthorized: false, // NeonDB exige isso
    },
});

export default pool;
