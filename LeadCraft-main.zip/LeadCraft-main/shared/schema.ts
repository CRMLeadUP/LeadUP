import { pgTable, text, serial, timestamp, integer, boolean } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";
import { relations } from "drizzle-orm";

export const users = pgTable("users", {
  id: serial("id").primaryKey(),
  email: text("email").notNull().unique(),
  name: text("name").notNull(),
  password: text("password").notNull(),
  plan: text("plan").default("free").notNull(),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export const leads = pgTable("leads", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull().references(() => users.id),
  name: text("name").notNull(),
  email: text("email"),
  phone: text("phone"),
  status: text("status").default("Novos Leads").notNull(),
  notes: text("notes"),
  createdAt: timestamp("created_at").defaultNow().notNull(),
  updatedAt: timestamp("updated_at").defaultNow().notNull(),
});

export const userPlans = pgTable("user_plans", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull().references(() => users.id),
  plan: text("plan").default("free").notNull(),
  active: boolean("active").default(true).notNull(),
  createdAt: timestamp("created_at").defaultNow().notNull(),
  updatedAt: timestamp("updated_at").defaultNow().notNull(),
});

export const usersRelations = relations(users, ({ many }) => ({
  leads: many(leads),
  plans: many(userPlans),
}));

export const leadsRelations = relations(leads, ({ one }) => ({
  user: one(users, {
    fields: [leads.userId],
    references: [users.id],
  }),
}));

export const userPlansRelations = relations(userPlans, ({ one }) => ({
  user: one(users, {
    fields: [userPlans.userId],
    references: [users.id],
  }),
}));

// Schemas
export const insertUserSchema = createInsertSchema(users)
  .omit({ id: true, createdAt: true })
  .extend({
    password: z.string().min(6, "A senha deve ter pelo menos 6 caracteres"),
    email: z.string().email("Email inválido"),
    name: z.string().min(3, "O nome deve ter pelo menos 3 caracteres"),
  });

export const insertLeadSchema = createInsertSchema(leads)
  .omit({ id: true, createdAt: true, updatedAt: true });

export const insertUserPlanSchema = createInsertSchema(userPlans)
  .omit({ id: true, createdAt: true, updatedAt: true });

export const leadStatusEnum = z.enum([
  "Novos Leads", 
  "Atendimento Iniciado", 
  "Agendamento", 
  "Negociação", 
  "Follow-up", 
  "Vendidos"
]);

export const userPlanEnum = z.enum(["free", "pro", "advanced"]);

// Types
export type InsertUser = z.infer<typeof insertUserSchema>;
export type InsertLead = z.infer<typeof insertLeadSchema>;
export type InsertUserPlan = z.infer<typeof insertUserPlanSchema>;

export type User = typeof users.$inferSelect;
export type Lead = typeof leads.$inferSelect;
export type UserPlan = typeof userPlans.$inferSelect;

export type LeadStatus = z.infer<typeof leadStatusEnum>;
export type UserPlanType = z.infer<typeof userPlanEnum>;
import { z } from 'zod';

export const UserSchema = z.object({
    id: z.string(),
    username: z.string().min(3).max(20),
    email: z.string().email(),
    password: z.string(),
});

export type User = z.infer<typeof UserSchema>;
